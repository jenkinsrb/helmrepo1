import csv
import random
import math
import zipfile

# Set seed for reproducibility
random.seed(42)

rows = 1200

def clip(value, low, high):
    return max(low, min(high, value))

# Generate synthetic telematics rows
data_rows = []
for _ in range(rows):
    engine_rpm = clip(random.normalvariate(1500, 200), 900, 2100)
    vehicle_speed = clip(random.normalvariate(70, 12), 35, 100)
    payload_weight = clip(random.normalvariate(9500, 1500), 3000, 20000)
    ambient_temp = clip(random.normalvariate(24, 7), -5, 45)
    route_incline = clip(random.normalvariate(1.0, 0.9), 0, 6)

    # fuel efficiency formula
    fuel_efficiency = (
        6
        - (engine_rpm - 1200) * 0.0008
        - (payload_weight - 7000) * 0.00012
        - (route_incline * 0.22)
        + (vehicle_speed * 0.012)
        - random.normalvariate(0, 0.15)
    )
    fuel_efficiency = clip(fuel_efficiency, 2.1, 6.2)

    data_rows.append([
        round(engine_rpm, 2),
        round(vehicle_speed, 2),
        round(payload_weight, 2),
        round(ambient_temp, 2),
        round(route_incline, 2),
        round(fuel_efficiency, 2)
    ])

# Save CSV
csv_filename = "Daimler_Truck_Telematics.csv"
with open(csv_filename, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow([
        "engine_rpm",
        "vehicle_speed",
        "payload_weight",
        "ambient_temp",
        "route_incline",
        "fuel_efficiency"
    ])
    writer.writerows(data_rows)

# Create ZIP file
zip_filename = "Daimler_Truck_Telematics.zip"
with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(csv_filename)

print("ZIP file created:", zip_filename)
